const NS = 'gzh.iceshroom'
const CODE = 'gpn_677a682e6963657368726f6f6d2e636f6e74656e74_6963657368726f6f6d'
const NATIVE_ART_TILE_WIDTH = 128
const ENGINE_PLANT_SCALE = .42
const DROP_DELAY = .8
const DROP_HEIGHT = 550
const DROP_VELOCITY = 1000
const DROP_ACCELERATION = 50
const DROP_SECONDS = (Math.sqrt(DROP_VELOCITY ** 2 + 2 * DROP_ACCELERATION * DROP_HEIGHT) - DROP_VELOCITY) / DROP_ACCELERATION
const live = entity => entity?.node?.isValid && entity.node.activeInHierarchy && !entity.dead && entity.isAlive?.() !== false
let modules

function placeBoardArt(control, squareWidth) {
  const placement = control.db?.armature()?.getBone('boardPlacement')
  if (!placement) return
  const scale = squareWidth / NATIVE_ART_TILE_WIDTH / ENGINE_PLANT_SCALE
  placement.offset.scaleX = scale
  placement.offset.scaleY = scale
  placement.invalidUpdate()
}

export default {
  startup(ctx) {
    const cc = ctx.engine.getCc()
    const module = name => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`)
    const { PlantPool, ZombiePool, TombPool, Rectangle, ZombieDamageDetails } = module('CharacterManager')
    const { Square } = module('Square')
    const { plants } = module('Plants')
    modules = { plants, Square, CardFeature: module('CardFeature').CardFeature,
      PlantIcon: module('PlantIcon').PlantIcon, AnimationController: module('AnimationController').AnimationController,
      UIInGame: module('UI').UIInGame, LnC: module('LnC').LnC }
    const files = ctx.files.own()
    const effects = {}
    let stats, audioMap
    const displays = new Set()
    const damageStates = new WeakMap()
    const width = () => Square.SquareWidth
    const height = () => Square.SquareHeight
    const artScale = () => width() / NATIVE_ART_TILE_WIDTH
    const remainingBoost = state => Math.max(1, ...[...state.sources].filter(([source, entry]) =>
      live(source) && source.iceClock < entry.until).map(([, entry]) => entry.multiplier))

    const grantBoost = (target, source, multiplier) => {
      let state = damageStates.get(target)
      if (!state) {
        const descriptor = Object.getOwnPropertyDescriptor(target, '_dmgScale')
        if (!descriptor?.configurable || !descriptor.writable) return
        state = { descriptor, base: descriptor.value, sources: new Map() }
        damageStates.set(target, state)
        Object.defineProperty(target, '_dmgScale', {
          configurable: true, enumerable: descriptor.enumerable,
          get: () => state.base * remainingBoost(state),
          set: value => { state.base = value },
        })
      }
      state.sources.set(source, { multiplier, until: source.iceClock + 2 })
      source.iceRecipients.add(target)
    }
    const revokeBoost = (target, source) => {
      const state = damageStates.get(target)
      if (!state) return
      state.sources.delete(source)
      if (!state.sources.size) {
        Object.defineProperty(target, '_dmgScale', { ...state.descriptor, value: state.base })
        damageStates.delete(target)
      }
    }

    async function loadEffect(name) {
      const [skeletonText, atlasText, png] = await Promise.all([
        files.readText(`fx/${name}_ske.json`), files.readText(`fx/${name}_tex.json`), files.readBytes(`fx/${name}.png`),
      ])
      const url = URL.createObjectURL(new Blob([png], { type: 'image/png' }))
      const image = new Image()
      try { image.src = url; await image.decode() } finally { URL.revokeObjectURL(url) }
      const texture = new cc.Texture2D()
      texture.image = new cc.ImageAsset(image)
      const skeleton = new cc.dragonBones.DragonBonesAsset()
      const atlas = new cc.dragonBones.DragonBonesAtlasAsset()
      skeleton.dragonBonesJson = skeletonText
      atlas.atlasJson = atlasText
      atlas.texture = texture
      effects[name] = { skeleton, atlas, texture }
    }
    ctx.registrations.add('iceshroom-media', {
      async prepare() {
        const [statText, soundText] = await Promise.all([
          files.readText('stats.json'), files.readText('audio.json'),
          ...['impact', 'melee', 'projectile', 'tile'].map(loadEffect),
        ])
        stats = JSON.parse(statText)
        audioMap = JSON.parse(soundText)
      },
      publish() {},
      dispose() {
        for (const node of displays) if (node.isValid) node.destroy()
        displays.clear()
        for (const { skeleton, atlas, texture } of Object.values(effects)) {
          skeleton.destroy(); atlas.destroy(); texture.destroy()
        }
      },
    })

    const remove = node => {
      displays.delete(node)
      if (node?.isValid) node.destroy()
    }
    function draw(name, clip, parent, position, playSound, loops = 1, completed) {
      if (!parent?.isValid || !effects[name]) return
      const node = new cc.Node(`Ice-shroom ${name}`)
      displays.add(node)
      node.parent = parent
      node.layer = parent.layer
      node.setWorldPosition(position)
      node.setScale(artScale(), artScale(), 1)
      const display = node.addComponent(cc.dragonBones.ArmatureDisplay)
      const { skeleton, atlas } = effects[name]
      display.dragonAsset = skeleton
      display.dragonAtlasAsset = atlas
      display.armatureName = 'Body'
      display.on(cc.dragonBones.EventObject.FRAME_EVENT, event => {
        if (event.name === 'PlaySample') playSound(event.data?.strings?.[0], node)
      })
      if (loops) display.on(cc.dragonBones.EventObject.COMPLETE, () => {
        if (completed) completed(display, node)
        else remove(node)
      })
      display.playAnimation(clip, loops)
      return node
    }

    const zombieLive = zombie => live(zombie) && zombie.isRealZombie !== false && !zombie.reversed && !zombie.potionInvisible
    const zombieCell = zombie => {
      if (!zombieLive(zombie) || zombie.worldPositionX > Square.transFrom_ox_To_gx(820)) return null
      const row = zombie.lIndex
      if (row < 0 || row >= Square.LaneCount) return null
      const left = Square.getSquareWorldPosition(row, 0).x
      const col = Math.floor((zombie.worldPositionX - left) / width() + .5)
      if (col < 0 || col >= Square.ColumnCount) return null
      const cell = Square.getLnC(row, col)
      return cell?.isInLawn() ? cell : null
    }
    const winterPlant = plant => plant.objdataOwn?.Family === 'Cold' || plant.Plant_Type_Data === CODE
    const hits = (x, y, w, h, entities) => {
      const rect = Rectangle.createRectangleCenter(new cc.Vec2(x, y), w, h)
      return entities.filter(target => {
        const body = target.bodyRecForShooter || target.bodyRec
        return body && rect.judgeCrossRec(body)
      })
    }
    const nearby = (x, y, r, entities) => hits(x, y, 2 * r * width(), 2 * r * height(), entities)
    const hurt = (target, amount) => target.dealDamage(new ZombieDamageDetails(amount, true, true, true, null))

    const framework = ctx.registry.resolve('pvzge.entities', 'entities')
    framework.registerBehavior(NS, 'ice', (Base, { sounds }) => class IceShroom extends Base {
      specialPlantOnEnable() {
        this.iceClock = 0
        this.iceNextPulse = .5
        this.iceNextAttack = 0
        this.iceRecipients = new Set()
        this.iceShots = []
        this.iceTiles = []
        this.anmControl.IdleAnim = 'Idle'
        this.anmControl.RandomAnim = []
        this.anmControl.WaterAnm = ['Water']
        this.anmControl.timeScaleDefault = 1
        placeBoardArt(this.anmControl, width())
        this.playIdle()
      }
      specialPlantOnDisable() {
        for (const target of this.iceRecipients || []) revokeBoost(target, this)
        for (const { node } of this.iceShots || []) remove(node)
        for (const node of this.iceTiles || []) {
          const display = node.getComponent(cc.dragonBones.ArmatureDisplay)
          if (node.isValid && display?.isValid) display.playAnimation('End', 1)
        }
        this.iceRecipients?.clear()
      }
      stat(name) {
        const level = Math.max(0, Math.min(9, (this.objdataOwn.IceShroomLevel || 1) - 1))
        return stats.levels[name][level] + (this._MintBoosted ? stats.powerups[name]?.[level] || 0 : 0)
      }
      playClip(name) {
        this.action = name
        this.anmControl.playAnimation(name, 1, 0, 1)
      }
      playIdle() { this.playClip(Math.random() < 12 / 13 ? 'Idle' : 'Idle2') }
      waterable() { return !this.fooding && this.action?.startsWith('Idle') }
      water() { if (!this.dead && this.waterable()) this.playClip('Water') }
      specialPlantFood() { this.playClip('PlantFood'); this.queueIce() }
      specialPlantFoodEnd() { if (live(this)) this.playIdle() }
      animationOnComplete(event) {
        if (!live(this) || event.animationState?.name !== this.action) return
        if (this.fooding && this.action === 'PlantFood') this.foodEnd()
        else this.playIdle()
      }
      playIceSound(name, node = this.node) {
        const choices = audioMap[name]
        if (!choices?.length || !node?.isValid) return
        const audio = sounds['s' + choices[Math.floor(Math.random() * choices.length)]]
        if (audio) (node.getComponent(cc.AudioSource) || node.addComponent(cc.AudioSource)).playOneShot(audio, 1)
      }
      animationListener(event) {
        const clip = event.animationState?.name
        if (event.name === 'PlaySample') this.playIceSound(event.data?.strings?.[0])
        if (event.name !== 'use_special' || !live(this) || clip !== this.action) return
        if (clip === 'Attack') this.strike()
      }

      specialPlantUpdate(delta, gameDelta) {
        if (!(gameDelta > 0) || !this.inLane || !this.iceShots) return
        this.iceClock += gameDelta
        this.advanceShots()
        if (this.iceClock >= this.iceNextPulse) {
          this.iceNextPulse += 1
          this.pulseAura()
        }
        if (delta > 0 && !this.fooding && this.stunned <= 0 &&
            this.action.startsWith('Idle') && this.iceClock >= this.iceNextAttack && this.meleeTargets().length) {
          this.iceNextAttack = this.iceClock + 1.5
          this.playClip('Attack')
        }
      }

      meleeTargets() {
        const cell = Square.getSquareWorldPosition(this.lIndex, this.cIndex)
        // The native grid rectangle starts in the plant's own column and adds ActionDamageArea to its width.
        const columns = 1 + (this.cIndex > 7 ? 1 : this.stat('IceShroom_ActionDamageArea'))
        const targets = [...this.inLane.zombiePool().filter(zombieLive), ...this.inLane.tombPool().filter(live)]
        return hits(cell.x + (columns - 1) * width() / 2, cell.y, columns * width(), height(), targets)
      }
      strike() {
        for (const target of this.meleeTargets()) {
          const point = target.worldPosition
          draw('melee', 'Effect', this.inLane.prjLayer,
            new cc.Vec3(point.x - 80 * width() / 64, point.y + 125 * height() / 76, 0), this.playIceSound.bind(this))
          hurt(target, this.stat('ActionDamage') * this._dmgScale)
          target.setChill?.(this.stat('IceShroom_ActionChillDuration'))
        }
      }
      pulseAura() {
        const point = Square.getSquareWorldPosition(this.lIndex, this.cIndex)
        const targets = new Set()
        for (const plant of PlantPool.pool()) {
          if (plant === this || !live(plant) || !winterPlant(plant) ||
              Math.abs(plant.lIndex - this.lIndex) > 1 || Math.abs(plant.cIndex - this.cIndex) > 1) continue
          targets.add(plant)
          grantBoost(plant, this, this.stat('IceShroom_AuraWinterMintDamageBoost'))
        }
        for (const target of this.iceRecipients) {
          if (!live(target) || (!targets.has(target) && this.iceClock >= damageStates.get(target)?.sources.get(this)?.until)) {
            revokeBoost(target, this)
            this.iceRecipients.delete(target)
          }
        }
        for (const zombie of nearby(point.x, point.y, 1.5, ZombiePool.pool().filter(zombieLive))) zombie.setChill?.(1)
        if (!this.iceTiles.length) {
          for (let row = this.lIndex - 1; row <= this.lIndex + 1; row++) {
            for (let col = this.cIndex - 1; col <= this.cIndex + 1; col++) {
              if (!Square.getLnC(row, col)?.isInLawn()) continue
              const cell = Square.getSquareWorldPosition(row, col)
              const tile = draw('tile', 'Spawn', Square.getLane(row)?.icetileLayer,
                new cc.Vec3(cell.x, cell.y, 0), this.playIceSound.bind(this), 1,
                (display, node) => {
                  if (display.armature()?.animation.lastAnimationName === 'End') remove(node)
                  else display.playAnimation('Loop', 0)
                })
              if (tile) this.iceTiles.push(tile)
            }
          }
        }
      }

      queueIce() {
        const candidates = ZombiePool.pool().filter(zombie => zombieCell(zombie) && zombie.lobberTarget?.())
        const count = this.stat('IceShroom_ProjectileSpawnCountPF')
        const damage = this.stat('ActionSplashDamagePF') * this._dmgScale
        const freeze = this.stat('IceShroom_FreezeDurationPF')
        const usedCells = new Set()
        for (let i = 0; i < count; i++) {
          const pick = Math.floor(Math.random() * candidates.length)
          const target = candidates.splice(pick, 1)[0]
          this.iceShots.push({ target, usedCells, damage, freeze, at: this.iceClock + (i + 1) * DROP_DELAY })
        }
      }
      dropPoint(shot) {
        const cells = []
        for (let row = 0; row < Square.LaneCount; row++) {
          for (let col = 0; col < Square.ColumnCount; col++) {
            const cell = Square.getLnC(row, col)
            if (cell?.isInLawn()) cells.push(cell)
          }
        }
        let cell = zombieCell(shot.target)
        if (!cell) {
          const unused = cells.filter(candidate => !shot.usedCells.has(candidate))
          const choices = unused.length ? unused : cells
          cell = choices[Math.floor(Math.random() * choices.length)]
        }
        if (!cell) return
        shot.usedCells.add(cell)
        const point = cell.plantPoint.worldPosition
        return new cc.Vec3(point.x, point.y + 20 * height() / 76, 0)
      }
      positionIcicle(node, point, time) {
        const forward = -110 + 210 * time + 25 * time ** 2
        const altitude = DROP_HEIGHT - DROP_VELOCITY * time - .5 * DROP_ACCELERATION * time ** 2
        node.setWorldPosition(point.x + forward * width() / 64,
          point.y + Math.max(0, altitude) * width() / 64, 0)
      }
      advanceShots() {
        this.iceShots = this.iceShots.filter(shot => {
          const elapsed = this.iceClock - shot.at
          if (elapsed < 0) return true
          if (!shot.node) {
            shot.point = this.dropPoint(shot)
            if (!shot.point) return false
            shot.node = draw('projectile', 'Effect', this.inLane.prjLayer, shot.point, this.playIceSound.bind(this), 0)
          }
          if (!shot.node?.isValid) return false
          this.positionIcicle(shot.node, shot.point, Math.min(elapsed, DROP_SECONDS))
          if (elapsed < DROP_SECONDS) return true
          const parent = shot.node.parent
          const end = shot.node.worldPosition.clone()
          remove(shot.node)
          draw('impact', 'Effect', parent, new cc.Vec3(end.x - 15 * width() / 64, end.y, 0), this.playIceSound.bind(this))
          const entities = [...ZombiePool.pool().filter(zombieLive), ...TombPool.pool().filter(live)]
          for (const target of nearby(end.x, end.y, 1, entities)) {
            hurt(target, shot.damage)
            target.setFreeze?.(shot.freeze)
          }
          return false
        })
      }
    })
  },

  setup(ctx) {
    ctx.plants.mutateFeatures(data => {
      if (Array.isArray(data.SANDBOX) && !data.SANDBOX.includes(CODE)) data.SANDBOX.push(CODE)
    })
    const { CardFeature, PlantIcon, plants, Square, AnimationController, UIInGame, LnC } = modules
    const card = CardFeature.prototype.cardGrouperPlant
    const icon = PlantIcon.prototype.switchPlant
    const costume = AnimationController.prototype.readCostume
    const showCard = function(...args) {
      const result = card.apply(this, args)
      if (this.PF?.CODENAME === CODE) this.ca._plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const showIcon = function(...args) {
      const result = icon.apply(this, args)
      if (plants.getPlantFeature(this.ID)?.CODENAME === CODE) this.plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const placePreview = function(...args) {
      const result = costume.apply(this, args)
      if (!this.node.name.endsWith(':display') || plants.getPlantFeature(this.ID)?.CODENAME !== CODE) return result
      const parent = this.node.parent
      if (parent === UIInGame.component?.plantInHandLayer || parent?.parent?.getComponent(LnC)?.ghostPoint === parent) {
        placeBoardArt(this, Square.SquareWidth)
      }
      return result
    }
    CardFeature.prototype.cardGrouperPlant = showCard
    PlantIcon.prototype.switchPlant = showIcon
    AnimationController.prototype.readCostume = placePreview
    ctx.runtime.onDispose(() => {
      if (CardFeature.prototype.cardGrouperPlant === showCard) CardFeature.prototype.cardGrouperPlant = card
      if (PlantIcon.prototype.switchPlant === showIcon) PlantIcon.prototype.switchPlant = icon
      if (AnimationController.prototype.readCostume === placePreview) AnimationController.prototype.readCostume = costume
    })
    ctx.controls.definePanel({
      title: '寒冰菇（国际版）',
      groups: [{ title: '普通关卡', items: [{
        key: 'unlock', type: 'action', label: '解锁寒冰菇（国际版）',
        onClick() {
          if (!ctx.plants.getFeature(CODE)) return ctx.ui.toast('请先启用寒冰菇内容包')
          const props = ctx.player.getProperty('plantProps')
          if (!props || typeof props !== 'object') return ctx.ui.toast('请先进入一个玩家存档')
          if (props[CODE]?.progress >= 1) return ctx.ui.toast('寒冰菇已解锁')
          ctx.player.setProperty('plantProps', { ...props, [CODE]: {
            medal: false, costume: -1, costumes: [], boost: 0, ...props[CODE], progress: 1, tutorialLevel: 1,
          } })
          ctx.ui.toast('寒冰菇已解锁，重新进入关卡后可选用')
        },
      }] }],
    })
  },
}

